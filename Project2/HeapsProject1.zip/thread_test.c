#include <unistd.h>
#include "threads.h"


int global = 0;
int threads, limit;

void f1(void) {
    int local = 0;
    while(local < limit) {
        global++;
        local++;
        printf("\n This is %d th execution of thread 1 with global var value %d \n", local, global);
        //sleep(1);
        yield();
    }

    return;
}


void f2(void) {
    int local = 0;
    while(local < limit) {
        global+=2;
        local++;
        printf("\n This is %d th execution of thread 2 with global var value %d \n", local, global);
        //sleep(1);
        yield();
    }

    return;
}


void f3(void) {
    int local = 0;
    while(local < limit) {
        global+=3;
        local++;
        printf("\n This is %d th execution of thread 3 with global var value %d \n", local, global);
        //sleep(1);
        yield();
    }

    return;
}

void f4(void) {
    int local = 0;
    while(local < limit) {
        global+=4;
        local++;
        printf("\n This is %d th execution of thread 4 with global var value %d \n", local, global);
        //sleep(1);
        yield();
    }

    return;
}

void f5(void) {
    int local = 0;
    while(local < limit) {
        global+=5;
        local++;
        printf("\n This is %d th execution of thread 5 with global var value %d \n", local, global);
        //sleep(1);
        yield();
    }

    return;
}

void f6(void) {
    int local = 0;
    while(local < limit) {
        global+=6;
        local++;
        printf("\n This is %d th execution of thread 6 with global var value %d \n", local, global);
        //sleep(1);
        yield();
    }

    return;
}

void f7(void) {
    int local = 0;
    while(local < limit) {
        global+=7;
        local++;
        printf("\n This is %d th execution of thread 7 with global var value %d \n", local, global);
        //sleep(1);
        yield();
    }

    return;
}

void f8(void) {
    int local = 0;
    while(local < limit) {
        global+=8;
        local++;
        printf("\n This is %d th execution of thread 8 with global var value %d \n", local, global);
        //sleep(1);
        yield();
    }

    return;
}

void f9(void) {
    int local = 0;
    while(local < limit) {
        global+=9;
        local++;
        printf("\n This is %d th execution of thread 9 with global var value %d \n", local, global);
        //sleep(1);
        yield();
    }

    return;
}

void f10(void) {
    int local = 0;
    while(local < limit) {
        global+=10;
        local++;
        printf("\n This is %d th execution of thread 10 with global var value %d \n", local, global);
        //sleep(1);
        yield();
    }

    return;
}

void f11(void) {
    int local = 0;
    while(local < limit) {
        global+=11;
        local++;
        printf("\n This is %d th execution of thread 11 with global var value %d \n", local, global);
        //sleep(1);
        yield();
    }

    return;
}

void f12(void) {
    int local = 0;
    while(local < limit) {
        global+=12;
        local++;
        printf("\n This is %d th execution of thread 12 with global var value %d \n", local, global);
        //sleep(1);
        yield();
    }

    return;
}

void f13(void) {
    int local = 0;
    while(local < limit) {
        global+=13;
        local++;
        printf("\n This is %d th execution of thread 13 with global var value %d \n", local, global);
        //sleep(1);
        yield();
    }

    return;
}

void f14(void) {
    int local = 0;
    while(local < limit) {
        global+=14;
        local++;
        printf("\n This is %d th execution of thread 14 with global var value %d \n", local, global);
        //sleep(1);
        yield();
    }

    return;
}

void f15(void) {
    int local = 0;
    while(local < limit) {
        global+=15;
        local++;
        printf("\n This is %d th execution of thread 15 with global var value %d \n", local, global);
        //sleep(1);
        yield();
    }

    return;
}

void f16(void) {
    int local = 0;
    while(local < limit) {
        global+=16;
        local++;
        printf("\n This is %d th execution of thread 16 with global var value %d \n", local, global);
        //sleep(1);
        yield();
    }

    return;
}

void f17(void) {
    int local = 0;
    while(local < limit) {
        global+=17;
        local++;
        printf("\n This is %d th execution of thread 17 with global var value %d \n", local, global);
        //sleep(1);
        yield();
    }

    return;
}

void f18(void) {
    int local = 0;
    while(local < limit) {
        global+=18;
        local++;
        printf("\n This is %d th execution of thread 18 with global var value %d \n", local, global);
        //sleep(1);
        yield();
    }

    return;
}

void f19(void) {
    int local = 0;
    while(local < limit) {
        global+=19;
        local++;
        printf("\n This is %d th execution of thread 19 with global var value %d \n", local, global);
        //sleep(1);
        yield();
    }

    return;
}

void f20(void) {
    int local = 0;
    while(local < limit) {
        global+=20;
        local++;
        printf("\n This is %d th execution of thread 20 with global var value %d \n", local, global);
        //sleep(1);
        yield();
    }

    return;
}

int main() {

    scanf("%d,%d", &threads, &limit);

    if (threads == 0) {
        printf("\n No Threads \n");
        return 0;
    }

    RunQ = (struct Queue*) malloc(sizeof(struct Queue));

    initQueue(RunQ);

    if (threads >= 1) {
        start_thread(f1);
    }
    if (threads >= 2) {
        start_thread(f2);
    }
    if (threads >= 3) {
        start_thread(f3);
    }
    if (threads >= 4) {
        start_thread(f4);
    }
    if (threads >= 5) {
        start_thread(f5);
    }
    if (threads >= 6) {
        start_thread(f6);
    }
    if (threads >= 7) {
        start_thread(f7);
    }
    if (threads >= 8) {
        start_thread(f8);
    }
    if (threads >= 9) {
        start_thread(f9);
    }
    if (threads >= 10) {
        start_thread(f10);
    }
    if (threads >= 11) {
        start_thread(f11);
    }
    if (threads >= 12) {
        start_thread(f12);
    }
    if (threads >= 13) {
        start_thread(f13);
    }
    if (threads >= 14) {
        start_thread(f14);
    }
    if (threads >= 15) {
        start_thread(f15);
    }
    if (threads >= 16) {
        start_thread(f16);
    }
    if (threads >= 17) {
        start_thread(f17);
    }
    if (threads >= 18) {
        start_thread(f18);
    }
    if (threads >= 19) {
        start_thread(f19);
    }
    if (threads >= 20) {
        start_thread(f20);
    }
    run();
    return 0;
}